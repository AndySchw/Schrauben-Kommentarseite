# HTML Formular mit JavaScript verarbeiten (inkl. Dateiupload)

HTML Formular effektiv mit JavaScript verarbeiten und serverseitig mit NodeJS empfangen. Und das alles inklusive Dateiupload. Neben JavaScript FormData und Fetch nutzen wir Pakete wie Express JS, CORS und Multer für NodeJS um alle Hürden für Anfänger zu überwinden. Happy Coding!

[![Tutorial bei Youtube](http://img.youtube.com/vi/uOE1aqyzq_w/0.jpg)](https://youtu.be/uOE1aqyzq_w)

## 📺 Playlists

[Webentwicklung für Anfänger](https://www.youtube.com/playlist?list=PLnqycjkeRGqmrzCAVKOc4RPhFWFMVpZ6x)

[CSS Tutorials Deutsch](https://www.youtube.com/playlist?list=PLnqycjkeRGqmNb4zay7i46-57KgnO_xcD)

[Visual Studio Code Tutorials](https://www.youtube.com/playlist?list=PLnqycjkeRGqmlJvXkxqSvIynlxaiKecPN)

[Frameworks, Libraries und Tools](https://www.youtube.com/playlist?list=PLnqycjkeRGqnqag9WBK1THbdwsf2E-6cV)

[Programmieren: Tipps, Ideen, Gedanken und Meinungen](https://www.youtube.com/playlist?list=PLnqycjkeRGqmxW1HaS897rvCapowxbtYH)

## Vernetze dich:

[<img align="left" alt="programmierenmitmario.de" width="22px" src="https://raw.githubusercontent.com/iconic/open-iconic/master/svg/globe.svg" />][website]
[<img align="left" alt="programmierenmitmario | YouTube" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/youtube.svg" />][youtube]
[<img align="left" alt="programmierenmitmario | Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />][twitter]
[<img align="left" alt="programmierenmitmario | Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />][instagram]
<br>
<br>

## Projekt Setup Backend

Führe diesen Befehl im Terminal einmalig aus um alle notwendigen Dependencies zu installieren.

```
npm install
```

### Starte WebServer für Development

```
npm run start
```

## License

[MIT](LICENSE)

[website]: http://programmierenmitmario.de
[twitter]: https://twitter.com/programmierenm
[youtube]: https://youtube.com/programmierenmitmario
[instagram]: https://instagram.com/programmierenm
